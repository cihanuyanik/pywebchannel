from enum import StrEnum


class SupportedTypes(StrEnum):
    Controller = "ControllerBase"
    Model = "BaseModel"
