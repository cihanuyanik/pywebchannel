////////////////////////////////////////////////////
// Auto generated file
// Generation time: 2023-12-11 14:37:30
////////////////////////////////////////////////////

import { Response } from "../models/Response";

// HelloWorldController interface
export interface HelloWorldController {
  // Slots
  sayHello(name: string): Promise<Response>;
}
