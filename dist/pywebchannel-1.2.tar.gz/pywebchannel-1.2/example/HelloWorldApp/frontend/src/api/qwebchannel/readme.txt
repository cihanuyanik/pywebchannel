+ index.js --> QWebChannel implementation
  - import through index.html
    -- <script type="text/javascript" src="src/qwebchannel"></script> 

+ index.d.s --> Typescript definitions embedded into global namespace