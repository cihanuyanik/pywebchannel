from enum import StrEnum


class SupportedTypes(StrEnum):
    Controller = "Controller"
    Model = "BaseModel"
